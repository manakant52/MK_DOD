const container = document.querySelector('.container');
const checkOrderButton = document.getElementById('checkOrderButton');
const resultMessage = document.getElementById('resultMessage');

let squares = document.querySelectorAll('.square');

// Функция для перемешивания массива (алгоритм Фишера-Йетса)
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Перемешиваем квадраты при загрузке страницы
window.addEventListener('load', () => {
    const squaresArray = Array.from(squares);
    const shuffledSquares = shuffleArray(squaresArray);

    // Очищаем контейнер с квадратами
    container.innerHTML = '';

    // Добавляем перемешанные квадраты обратно в контейнер
    shuffledSquares.forEach(square => {
        container.appendChild(square);
    });

    // Обновляем массив squares
    squares = document.querySelectorAll('.square');
    addDragAndDropListeners(); // Добавляем обработчики событий для новых квадратов
});

// Добавляем обработчики событий для перетаскивания
function addDragAndDropListeners() {
    squares.forEach(square => {
        square.addEventListener('dragstart', dragStart);
        square.addEventListener('dragover', dragOver);
        square.addEventListener('drop', drop);
        square.addEventListener('dragend', dragEnd); // Добавляем обработчик dragend
    });
}

function dragStart(e) {
    e.dataTransfer.setData('text/plain', e.target.getAttribute('data-part')); // Используем data-part для идентификации
    setTimeout(() => {
        e.target.classList.add('invisible');
    }, 0);
}

function dragOver(e) {
    e.preventDefault();
}

function drop(e) {
    e.preventDefault();

    const draggedPart = e.dataTransfer.getData('text/plain');
    const targetPart = e.target.getAttribute('data-part');

    if (draggedPart && targetPart && draggedPart !== targetPart) {
        const draggedSquare = [...squares].find(sq => sq.getAttribute('data-part') === draggedPart);
        const targetSquare = e.target.closest('.square');

        // Меняем местами квадраты
        const tempHTML = draggedSquare.innerHTML;
        draggedSquare.innerHTML = targetSquare.innerHTML;
        targetSquare.innerHTML = tempHTML;

        // Обновляем data-part
        draggedSquare.setAttribute('data-part', targetPart);
        targetSquare.setAttribute('data-part', draggedPart);
    }
}

// Обработчик завершения перетаскивания
function dragEnd(e) {
    e.target.classList.remove('invisible'); // Убираем невидимость
}

// Проверка порядка квадратов
checkOrderButton.addEventListener('click', () => {
    const correctOrder = ['1', '2', '3', '4', '5', '6', '7']; // Правильный порядок data-part

    // Получаем текущий порядок квадратов
    const currentOrder = Array.from(squares).map(square => square.getAttribute('data-part'));

    // Убираем предыдущие подсветки
    squares.forEach(square => {
        square.classList.remove('correct', 'incorrect');
    });

    // Проверяем каждый квадрат
    let allCorrect = true;
    squares.forEach((square, index) => {
        if (square.getAttribute('data-part') === correctOrder[index]) {
            square.classList.add('correct'); // Подсвечиваем зелёным, если квадрат на правильном месте
        } else {
            square.classList.add('incorrect'); // Подсвечиваем красным, если квадрат на неправильном месте
            allCorrect = false;
        }
    });

    if (allCorrect) {
        resultMessage.textContent = "Порядок квадратов правильный! Запускаем игру...";
        resultMessage.style.color = "green";

        // Собираем код игры из квадратов
        let fullGameCode = '';
        squares.forEach(square => {
            const code = square.querySelector('pre').textContent;
            fullGameCode += code + '\n';
        });

        // Запускаем игру
        try {
            eval(fullGameCode); // Выполняем собранный код
        } catch (error) {
            console.error('Ошибка при запуске игры:', error);
        }

        // Переход на песню "Never Gonna Give You Up"
        window.open("saper.html", "_blank");
    } else {
        resultMessage.textContent = "Порядок квадратов неправильный. Попробуйте снова!";
        resultMessage.style.color = "red";
    }
});

// Инициализация
addDragAndDropListeners();