const totalBugs = 5;
let bugs = 0
let qb = false
let ue = false
let eb = false
let rb = false
let tb = false
const EMAIL_REGEXP = /^(([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/iu;
function totf() {
    alert(`Всего багов ${totalBugs}`)
}



function move() {
    var elem = document.getElementById("Bar");
    var ud = setInterval(frame, 10);
    function frame() {
        elem.setAttribute("value", bugs)
    }
}

function u() {

}

function e() {
    if (eb == false) {
        eb = true
        bugs += 1
        move()
        alert(`Ты нашёл ${bugs} из ${totalBugs}. По непонятным причинам последний символ пропадает`)
    }
}

function t() {
    if (tb == false) {
        tb = true
        bugs += 1
        move()
        alert(`Ты нашёл ${bugs} из ${totalBugs}. Опечатка тоже бага))) `)
    }
}

function dots() {
    if (rb == false) {
        rb = true;
        bugs += 1;
        move()
        alert(`Ты нашёл ${bugs} из ${totalBugs}. Изображение должно появляться вместе с загрузкой страницы`);
    } else {
        rb = true;
    }
}

function q() {
    if (qb == false) {

        qb = true;
        bugs += 1;
        move()
        alert(`Ты нашёл ${bugs} из ${totalBugs}. При наведении цвет текста изменяется на цвет фона, что мешает пользователю взаимодействовать с интерфейсом`);
    } else {
        qb = true;
    }
}

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function mail() {
    var val = String(document.getElementById("email").value);
    document.getElementById("fmail").innerHTML = val;
    if (validateEmail(val) == false && ue == false) {
        ue = true
        bugs += 1
        move()
        alert(`Ты нашёл ${bugs} из ${totalBugs}. Некорректный e-mail - это очень и очень плохо!`)
    }

}

function imya() {
    var val = String(document.getElementById("imya").value);
    const s = val.slice(0, -1)
    document.getElementById("imyaa").innerHTML = s;
}

function about() {
    var val = document.getElementById("about").value;
    document.getElementById("abouta").innerHTML = val;
}

function name_project1() {
    var val = document.getElementById("name_project1").value;
    document.getElementById("name_project1a").innerHTML = val;
}

function name_project2() {
    var val = document.getElementById("name_project2").value;
    document.getElementById("name_project2a").innerHTML = val;
}

function project1() {
    var val = document.getElementById("project1").value;
    document.getElementById("project1a").innerHTML = val;
}

function project2() {
    var val = document.getElementById("project2").value;
    document.getElementById("project2a").innerHTML = val;
}

function submitButtonHandler() {
    imya();
    about();
    mail();
    name_project1();
    name_project2();
    project1();
    project2();
}

var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
    showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active";
}